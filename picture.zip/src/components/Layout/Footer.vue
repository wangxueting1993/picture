<template>
  <div class="footer">
    <div>关于我们  |  联系我们</div> 
    <div>

    ©2019 北京中盈信安科技发展有限责任公司版权所有
    </div>
  </div>
</template>
<script>
export default {
  name: 'footers'
}
</script>
<style lang="stylus" scoped>
.footer {
  width: 100%;
  // height: 54px;
  line-height: 40px;
  color: #D8D8D8;
  font-size: 13px;
  background-color: #333333;
}
</style>
